package com.example.acer.api;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText location;
    TextView textView;

    GetLocation getLocation;
    String loc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        location = (EditText) findViewById(R.id.editText);
        textView = (TextView) findViewById(R.id.textView);
        loc = location.getText().toString();
      //  pb=(ProgressBar)findViewById(R.id.progressBar);
    }

    public void showdata(View view) {
        String loc=location.getText().toString();
       // pb.setVisibility(view.VISIBLE);
   getLocation=new GetLocation(MainActivity.this,location,textView);
   getLocation.execute(loc);
    }
}
