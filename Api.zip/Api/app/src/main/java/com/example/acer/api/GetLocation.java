package com.example.acer.api;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetLocation extends AsyncTask<String,Void,String> {
    Context context;
    EditText loc1;
    TextView textView1;
    StringBuffer sb;
    InputStream is;
    InputStreamReader isr;
    BufferedReader br;

    public GetLocation(MainActivity mainActivity, EditText location, TextView textView) {
        this.context = mainActivity;
        this.loc1 = location;
        this.textView1 = textView;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... strings) {
       
        String loc3 = strings[0];
        String response;
        String url = "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%3D%22"+loc3+"%2C%20ak%22)&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";
        try {
            URL u = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) u.openConnection();

            is = connection.getInputStream();
            br = new BufferedReader(new InputStreamReader(is));
            isr=new InputStreamReader(is);
            sb=new StringBuffer();

            while ((response = br.readLine())!= null) {
                sb.append(response);
            }
            return sb.toString();


        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        try {
            JSONObject object = new JSONObject(s);
            JSONObject query=object.getJSONObject("query");
            JSONObject result=query.getJSONObject("results");
            JSONObject channel=result.getJSONObject("channel");
            JSONObject item=channel.getJSONObject("item");
            JSONObject condition=item.getJSONObject("condition");
            JSONArray jsonArray=item.getJSONArray("forecast");
            JSONObject jo=jsonArray.getJSONObject(0);
            String c="",date="",day="",h="",l="",tt="";
            for (int i=0;i<jsonArray.length();i++)
            {
                c=jo.getString("code");
                date=jo.getString("date");
                day=jo.getString("day");
                h=jo.getString("high");
                l=jo.getString("low");
                tt=jo.getString("text");
            }

            String d=condition.getString("date");
            String tem=condition.getString("temp");
            String text=condition.getString("text");

            int t=Integer.parseInt(tem);
            double ft=(t-32)*0.5559;
            int i=(int)ft;
            textView1.setText(c+"\n"+date+"\n"+day+"\n"+h+"\n"+l+"\n"+tt+"\n"+d+"\n"+i+"°"+"C"+text);



        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
